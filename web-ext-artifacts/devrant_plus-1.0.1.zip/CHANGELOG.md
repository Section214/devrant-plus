# Changelog

## 1.0.1, February 9, 2017

* Improved: Back link generation
* Fixed: Prevent display of back link if there's nowhere to go back to


## 1.0.0, February 8, 2017

* Initial release
